batch_size     = 8
learning_rate  = 0.0001
epochs         = 30

from model import DepthEstimate

model = DepthEstimate()

from data import DataLoader

dl = DataLoader()
train_generator = dl.get_batched_dataset(batch_size)

print('Data loader ready.')

import tensorflow
from loss import depth_loss_function

optimizer = tensorflow.keras.optimizers.Adam(lr=learning_rate, amsgrad=True)

model.compile(loss=depth_loss_function, optimizer=optimizer)

# Create checkpoint callback
import os
checkpoint_path = "training"

callbacks = [
    tf.keras.callbacks.ModelCheckpoint(
        checkpoint_dir + "/ckpt={epoch:03d}", save_freq=10, verbose=1 
    )
]
# Start training
model.fit(train_generator, epochs=epochs, steps_per_epoch=dl.length//batch_size, callbacks=callbacks)